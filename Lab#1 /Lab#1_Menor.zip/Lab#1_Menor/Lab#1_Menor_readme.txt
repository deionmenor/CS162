@Deion Tristan C. Menor 154940

This program simply prompts the user for their name and subsequently prints out 3 line: the name given, the name but with all characters but the first replaced with #, and finally a string where all letters are changed to the next letter of the alphabet (non-alphabetical characters are unchanged)

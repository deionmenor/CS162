This code finds the Manhattan distance of an arbitrary number of points specified by the user.
The first line is for the number of test cases. Afterwards the user will input the number of 3D points to follow.

This program detects whether a provided input of processes and resources
will result in a deadlock or not. The testfile given shows three scenarios,
a.) when no deadlock occurs, and all processes runs ( in this case the program
prints the order they all run)
b.) when a deadlock occurs right away, and 
c.) a deadlock occurs after at least one process has already run.
